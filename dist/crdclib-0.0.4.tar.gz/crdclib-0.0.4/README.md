# CRDCLib
Personal library of CRDC routines I use a lot.  Theres nothing special, just saving writing time.
*Use at your own risk*
